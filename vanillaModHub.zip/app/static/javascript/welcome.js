
console.log('%c Vanilla Remastered ModHub ', "color: #02B875; font-size: 24px;");
console.log('%c Found this page? Nice. Head over to vanilla-remastered.com/careers.html', "color: #02B875; font-size: 16px;");

console.log('%c If someone told you to paste something in here, DO NOT! There is a 9/11 chance that you are being scammed', "color: #ff9900; font-size: 12px;");